import CampusSwipe from "@/components/CampusSwipe.jsx"
export default function App(){ return <CampusSwipe /> }