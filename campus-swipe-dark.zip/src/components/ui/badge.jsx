import React from 'react'
export function Badge({className="", variant="default", ...props}){
  const base="inline-flex items-center rounded-full px-3 py-1 text-xs font-medium"
  const variants={ default:"bg-neutral-800 text-white border border-neutral-700", outline:"border border-neutral-700 text-white" }
  return <span className={`${base} ${variants[variant]||variants.default} ${className}`} {...props}/>
}