import React from 'react'
export function Button({className="", variant="default", ...props}){
  const base = "inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 text-sm font-medium transition active:scale-[0.98]"
  const variants = {
    default: "bg-white text-black hover:bg-neutral-200",
    secondary: "bg-neutral-800 text-white hover:bg-neutral-700",
    outline: "border border-neutral-700 text-white hover:bg-neutral-800",
    ghost: "text-white hover:bg-neutral-800",
    destructive: "bg-red-600 text-white hover:bg-red-700",
  }
  return <button className={`${base} ${variants[variant]||variants.default} ${className}`} {...props} />
}