import React from 'react'
export const Input = React.forwardRef(function Input({className="", ...props}, ref){
  return <input ref={ref} className={`w-full rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 text-sm text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-neutral-500 ${className}`} {...props}/>
})